<?php
// khai báo biến hàng số trong php
define("PATH_IMG_PRODUCT","uploads/product/");
define("PATH_IMG_NEWS","uploads/news/");
define("PATH_IMG_BANNER","uploads/banner/");
define("PATH_IMG_USER","uploads/user/");

?>