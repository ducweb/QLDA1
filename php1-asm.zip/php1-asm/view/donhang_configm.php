<div class="main-banner2" id="home">
       </div>
<section class="ab-info-main py-5">
<div class="container py-lg-3">
    <div class="ab-info-grids">
        <div id="products" class="row view-group">      
<div class="containerfull">
<h3 class="tittle text-center mb-lg-5 mb-3">SẢN PHẨM</h3>
    </div>

    <section class="containerfull">
        <div class="container">
          <h2>Cảm ơn quý khách đã đặt thành công.
            <br>
            Quý khách có thể theo dõi đơn hàng <a href="index.php?pg=donhang&idbill=1">tại đây.<br>
            Mã đơn hàng: </a>
            <br>
            <a href="index.php?pg=home">Thoát</a>
          </h2>
          <br>
        </div>
    </section>

 </div> 
  </div> 
    </div>
    </section>
